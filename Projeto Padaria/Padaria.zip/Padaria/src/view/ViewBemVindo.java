package view;

public class ViewBemVindo {
    
    public static void bemVindo() {
        System.out.println("Seja muito bem-vindo(a)!");
    }
}
