package controller;

public class ControllerInterfaceController {
    public static String receitasDisponiveis = "";
    public static String receitasIndisponiveis= "";
}
