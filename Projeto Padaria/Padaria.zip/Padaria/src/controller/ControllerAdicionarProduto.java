package controller;

import view.ViewAdicionarProdutos;

public class ControllerAdicionarProduto {
    public static void adicionarProdutos() {
        int receita, quantidade;

        receita = ViewAdicionarProdutos.receita;
        quantidade = ViewAdicionarProdutos.qtdDoProduto;
    }
}
